# 淘宝直播 TCL 六家店单次核对

2026-11-23 12:41:44（北京时间），使用已登录的真实 Chrome，在现有 TCL 搜索页选中的「主播」标签核对一次。六家目标店均有「进入」按钮，脚本为每家输出了独立的 liveId 和直播间链接。该时间为读取卡片的时间。直播视频播放、正式开播时间、下播状态变化以及腾讯云部署情况均未在本轮验证。

## 原件与复核

- terminal.txt 是本轮完整的程序标准输出及标准错误，共 1,054 字节。它的 SHA-256 与 Codespace 中用原文件字节计算的值一致。命令结束后，外层终端另行打印了 TCL_SIX_ONCE_EXIT=0。
- TCL_six_cards_once_1123a.zip 是本轮使用的源码压缩包，含六店解析相关文件和原始校验清单。原始包的 SHA-256 已与工作区使用的值核对。
- SHA256SUMS.txt 可供独立核验。解压外层 ZIP 后执行 sha256sum -c SHA256SUMS.txt。每家店的状态、liveId 和链接见 terminal.txt。
- 观察范围为指定六店。页面第一排前五张卡片和第二排第一张卡片可见红色「进入」按钮。本轮仅从卡片读取链接，未进入直播间。

## 复用原界面

GitHub Codespace 名为 organic giggle。原 Chrome 已将搜索页加入「其他书签」，书签名为「搜索 - 淘宝直播」。工作区内保留原 Chrome 配置。GitHub 已确认本次测试结束后停止工作区。下次启动同一工作区并复用原配置即可打开该入口；需要时选「主播」。淘宝会话有效期由平台决定。

如需重复同一项人工确认后的单次核对，在同一 Codespace 的终端运行：

    cd /workspaces/tcl-live-monitor/.tcl-taobao-local/six-once-1123-Hq85oF
    DISPLAY=:1 python -u monitor_local.py --same-tab --once --local-only

看到该窗口中的 TCL 主播卡片后在终端按回车。本包不包含浏览器配置、登录凭据或用户截图。
